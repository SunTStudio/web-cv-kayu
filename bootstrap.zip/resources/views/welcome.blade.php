<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kayu Jaya - Supplier & Penjualan Kayu Berkualitas</title>
    <meta name="description" content="Kayu Jaya - Penyedia dan penjualan kayu berkualitas tinggi dengan harga terbaik">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=poppins:400,500,600,700,800" rel="stylesheet" />

    <!-- Styles -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
        }

        :root {
            --wood-dark: #3E2723;
            --wood-medium: #5D4037;
            --wood-light: #8D6E63;
            --wood-gold: #D4A574;
            --wood-cream: #F5F0EB;
            --accent-orange: #E67E22;
            --accent-gold: #F39C12;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0px) rotate(0deg);
            }

            50% {
                transform: translateY(-20px) rotate(2deg);
            }
        }

        @keyframes float-delayed {

            0%,
            100% {
                transform: translateY(0px) rotate(0deg);
            }

            50% {
                transform: translateY(-15px) rotate(-2deg);
            }
        }

        @keyframes pulse-glow {

            0%,
            100% {
                box-shadow: 0 0 20px rgba(212, 165, 116, 0.3);
            }

            50% {
                box-shadow: 0 0 40px rgba(212, 165, 116, 0.6);
            }
        }

        @keyframes slide-up {
            from {
                opacity: 0;
                transform: translateY(50px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scale-in {
            from {
                opacity: 0;
                transform: scale(0.8);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        @keyframes wave {
            0% {
                transform: translateX(0);
            }

            100% {
                transform: translateX(-50%);
            }
        }

        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }

            100% {
                background-position: 200% 0;
            }
        }

        @keyframes rotate-slow {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        .parallax {
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .animate-float {
            animation: float 6s ease-in-out infinite;
        }

        .animate-float-delayed {
            animation: float-delayed 7s ease-in-out infinite;
            animation-delay: 1s;
        }

        .animate-pulse-glow {
            animation: pulse-glow 3s ease-in-out infinite;
        }

        .animate-wave {
            animation: wave 15s linear infinite;
        }

        .animate-shimmer {
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            background-size: 200% 100%;
            animation: shimmer 2s infinite;
        }

        .animate-rotate-slow {
            animation: rotate-slow 20s linear infinite;
        }

        .scroll-animate {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .scroll-animate.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .scroll-animate-left {
            opacity: 0;
            transform: translateX(-50px);
            transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .scroll-animate-left.visible {
            opacity: 1;
            transform: translateX(0);
        }

        .scroll-animate-right {
            opacity: 0;
            transform: translateX(50px);
            transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .scroll-animate-right.visible {
            opacity: 1;
            transform: translateX(0);
        }

        .card-hover {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card-hover:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        .image-hover-zoom {
            overflow: hidden;
        }

        .image-hover-zoom img {
            transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .image-hover-zoom:hover img {
            transform: scale(1.15);
        }

        .gradient-text {
            background: linear-gradient(135deg, #D4A574 0%, #E67E22 50%, #F39C12 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, #8D6E63, #5D4037);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, #D4A574, #8D6E63);
        }

        .btn-wood {
            background: linear-gradient(135deg, #5D4037 0%, #3E2723 100%);
            position: relative;
            overflow: hidden;
            box-shadow: inset 0 2px 5px rgba(255, 255, 255, 0.1), 0 5px 15px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .btn-wood::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: all 0.5s ease;
        }

        .btn-wood:hover::before {
            left: 100%;
        }

        .btn-wood:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(62, 39, 35, 0.4);
            border-color: #D4A574;
        }

        .nav-transparent {
            background: transparent;
            transition: all 0.3s ease;
        }

        .nav-solid {
            background: rgba(62, 39, 35, 0.95);
            backdrop-filter: blur(10px);
        }

        .particle {
            position: absolute;
            width: 10px;
            height: 10px;
            background: rgba(212, 165, 116, 0.5);
            border-radius: 50%;
            animation: float 8s ease-in-out infinite;
        }

        .testimonial-card {
            background: linear-gradient(145deg, #ffffff 0%, #f8f4ef 100%);
            border: 1px solid rgba(212, 165, 116, 0.2);
        }

        .product-card {
            background: white;
            border: none;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }

        .product-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #D4A574, #E67E22, #D4A574);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.4s ease;
        }

        .product-card:hover::after {
            transform: scaleX(1);
        }

        .input-wood {
            border: 2px solid #e0d5cb;
            transition: all 0.3s ease;
        }

        .input-wood:focus {
            border-color: #D4A574;
            box-shadow: 0 0 0 4px rgba(212, 165, 116, 0.15);
            outline: none;
        }

        .delay-100 {
            animation-delay: 0.1s;
        }

        .delay-200 {
            animation-delay: 0.2s;
        }

        .delay-300 {
            animation-delay: 0.3s;
        }

        .delay-400 {
            animation-delay: 0.4s;
        }

        .delay-500 {
            animation-delay: 0.5s;
        }

        .mobile-menu {
            transform: translateX(100%);
            transition: transform 0.3s ease;
        }

        .mobile-menu.active {
            transform: translateX(0);
        }

        .bg-wood-pattern {
            background-image:
                radial-gradient(circle at 25% 25%, rgba(212, 165, 116, 0.1) 2px, transparent 2px),
                radial-gradient(circle at 75% 75%, rgba(212, 165, 116, 0.1) 2px, transparent 2px);
            background-size: 60px 60px;
        }

        .wood-grain-overlay {
            background-image: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.08'/%3E%3C/svg%3E");
            pointer-events: none;
        }
    </style>
</head>

<body class="font-poppins bg-[#F5F0EB] text-gray-800">

    <!-- Navigation -->
    <nav id="navbar" class="nav-transparent fixed w-full z-50 top-0 left-0">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <div class="flex-shrink-0 flex items-center">
                    <div class="flex items-center gap-2">
                        <div
                            class="w-12 h-12 rounded-full bg-gradient-to-br from-[#D4A574] to-[#3E2723] flex items-center justify-center">
                            <span class="text-white text-2xl font-bold">K</span>
                        </div>
                        <div>
                            <h1 class="text-2xl font-bold text-white">Kayu<span class="text-[#D4A574]">Jaya</span></h1>
                            <p class="text-xs text-gray-300">Supplier Kayu Terpercaya</p>
                        </div>
                    </div>
                </div>

                <div class="hidden md:flex items-center space-x-8">
                    <a href="#beranda" class="text-white hover:text-[#D4A574] transition-colors font-medium">Beranda</a>
                    <a href="#tentang" class="text-white hover:text-[#D4A574] transition-colors font-medium">Tentang</a>
                    <a href="#produk" class="text-white hover:text-[#D4A574] transition-colors font-medium">Produk</a>
                    <a href="#keunggulan"
                        class="text-white hover:text-[#D4A574] transition-colors font-medium">Keunggulan</a>
                    <a href="#galeri" class="text-white hover:text-[#D4A574] transition-colors font-medium">Galeri</a>
                    <a href="#testimoni"
                        class="text-white hover:text-[#D4A574] transition-colors font-medium">Testimoni</a>
                    <a href="#kontak" class="btn-wood text-white px-6 py-2.5 rounded-full font-semibold">Hubungi
                        Kami</a>
                </div>

                <div class="md:hidden flex items-center">
                    <button id="mobile-menu-btn" class="text-white p-2">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="mobile-menu fixed inset-0 z-40 bg-[#3E2723] md:hidden">
        <div class="flex flex-col items-center justify-center h-full space-y-8">
            <a href="#beranda"
                class="text-white text-2xl font-semibold hover:text-[#D4A574] transition-colors">Beranda</a>
            <a href="#tentang"
                class="text-white text-2xl font-semibold hover:text-[#D4A574] transition-colors">Tentang</a>
            <a href="#produk"
                class="text-white text-2xl font-semibold hover:text-[#D4A574] transition-colors">Produk</a>
            <a href="#keunggulan"
                class="text-white text-2xl font-semibold hover:text-[#D4A574] transition-colors">Keunggulan</a>
            <a href="#galeri"
                class="text-white text-2xl font-semibold hover:text-[#D4A574] transition-colors">Galeri</a>
            <a href="#testimoni"
                class="text-white text-2xl font-semibold hover:text-[#D4A574] transition-colors">Testimoni</a>
            <a href="#kontak"
                class="text-white text-2xl font-semibold hover:text-[#D4A574] transition-colors">Kontak</a>
            <button id="close-mobile-menu" class="absolute top-6 right-6 text-white">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
    </div>

    <!-- Hero Section -->
    <section id="beranda" class="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div class="absolute inset-0">
            <img src="https://images.unsplash.com/photo-1541123603104-512919d6a96c?w=1920&q=80" alt="Wood Background"
                class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-[#3E2723]/95 via-[#3E2723]/80 to-[#3E2723]/60"></div>
        </div>

        <div class="absolute inset-0 overflow-hidden pointer-events-none">
            <div class="particle animate-float" style="top: 20%; left: 10%; width: 20px; height: 20px;"></div>
            <div class="particle animate-float-delayed" style="top: 40%; right: 15%; width: 15px; height: 15px;"></div>
            <div class="particle animate-float" style="top: 60%; left: 20%; width: 12px; height: 12px;"></div>
            <div class="particle animate-float-delayed" style="top: 30%; right: 25%; width: 18px; height: 18px;">
            </div>
        </div>

        <div
            class="absolute -left-20 top-1/2 -translate-y-1/2 w-64 h-64 border-4 border-[#D4A574]/30 rounded-full animate-rotate-slow">
        </div>
        <div class="absolute -right-20 bottom-1/4 w-48 h-48 border-4 border-[#D4A574]/20 rounded-full animate-rotate-slow"
            style="animation-direction: reverse;"></div>

        <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div class="space-y-8">
                <div
                    class="scroll-animate inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 px-6 py-2 rounded-full">
                    <span class="w-2 h-2 bg-[#D4A574] rounded-full animate-pulse"></span>
                    <span class="text-white/90 text-sm font-medium">Supplier Kayu Berkualitas Sejak 1995</span>
                </div>

                <h1 class="scroll-animate text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
                    Kualitas Kayu
                    <span class="block gradient-text">Terbaik Untuk</span>
                    <span class="block text-[#D4A574]">Proyek Anda</span>
                </h1>

                <p class="scroll-animate delay-100 text-white/80 text-lg md:text-xl max-w-2xl mx-auto">
                    Menyediakan berbagai jenis kayu berkualitas tinggi dengan harga kompetitif.
                    Layanan profesional & pengiriman ke seluruh Indonesia.
                </p>

                <div class="scroll-animate delay-200 flex flex-col sm:flex-row items-center justify-center gap-4">
                    <a href="#produk" class="btn-wood px-10 py-4 rounded-full text-white font-semibold text-lg">
                        Lihat Produk
                        <svg class="inline-block ml-2 w-5 h-5" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                    </a>
                    <a href="#kontak"
                        class="px-10 py-4 rounded-full border-2 border-white text-white font-semibold text-lg hover:bg-white hover:text-[#3E2723] transition-all duration-300">
                        Hubungi Kami
                    </a>
                </div>

                <div class="scroll-animate delay-300 grid grid-cols-2 md:grid-cols-4 gap-8 pt-12">
                    <div class="text-center">
                        <div class="text-4xl md:text-5xl font-bold text-[#D4A574] counter" data-target="25">0</div>
                        <div class="text-white/70 mt-2">Tahun Pengalaman</div>
                    </div>
                    <div class="text-center">
                        <div class="text-4xl md:text-5xl font-bold text-[#D4A574] counter" data-target="5000">0</div>
                        <div class="text-white/70 mt-2">Proyek Selesai</div>
                    </div>
                    <div class="text-center">
                        <div class="text-4xl md:text-5xl font-bold text-[#D4A574] counter" data-target="10000">0</div>
                        <div class="text-white/70 mt-2">Pelanggan Puas</div>
                    </div>
                    <div class="text-center">
                        <div class="text-4xl md:text-5xl font-bold text-[#D4A574] counter" data-target="50">0</div>
                        <div class="text-white/70 mt-2">Jenis Kayu</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="absolute bottom-0 left-0 w-full">
            <svg class="w-full h-24 md:h-32" viewBox="0 0 1440 120" fill="none">
                <path
                    d="M0 120L60 105C120 90 240 60 360 45C480 30 600 30 720 37.5C840 45 960 60 1080 67.5C1200 75 1320 75 1380 75L1440 75V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
                    fill="#F5F0EB" />
            </svg>
        </div>
    </section>

    <!-- About Section -->
    <section id="tentang" class="py-20 md:py-32 bg-[#F5F0EB] bg-wood-pattern">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid lg:grid-cols-2 gap-16 items-center">
                <div class="scroll-animate-left relative">
                    <div class="relative">
                        <img src="https://images.unsplash.com/photo-1504198458649-3128b932f49e?auto=format&fit=crop&w=800&q=80"
                            alt="Tentang Kayu Jaya"
                            class="rounded-2xl shadow-2xl w-full object-cover h-[400px] md:h-[500px]">
                        <div
                            class="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-xl p-6 max-w-xs hidden md:block animate-float">
                            <div class="flex items-center gap-4">
                                <div class="w-14 h-14 rounded-full bg-[#D4A574]/20 flex items-center justify-center">
                                    <svg class="w-8 h-8 text-[#D4A574]" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="text-2xl font-bold text-[#3E2723]">100%</div>
                                    <div class="text-gray-600 text-sm">Kayu Berkualitas</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="absolute -top-4 -left-4 w-24 h-24 border-4 border-[#D4A574]/30 rounded-2xl"></div>
                    <div class="absolute -bottom-4 -right-4 w-16 h-16 bg-[#D4A574]/20 rounded-full"></div>
                </div>

                <div class="scroll-animate-right">
                    <div class="inline-flex items-center gap-2 bg-[#D4A574]/10 px-4 py-2 rounded-full mb-6">
                        <span class="w-2 h-2 bg-[#D4A574] rounded-full"></span>
                        <span class="text-[#D4A574] font-semibold text-sm">TENTANG KAMI</span>
                    </div>

                    <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-[#3E2723] mb-6 leading-tight">
                        Mengapa Memilih
                        <span class="gradient-text">Kayu Jaya?</span>
                    </h2>

                    <p class="text-gray-600 text-lg mb-8 leading-relaxed">
                        Kayu Jaya adalah supplier kayu terpercaya yang telah berpengalaman lebih dari 25 tahun dalam
                        industri kayu.
                        Kami berkomitmen untuk memberikan kualitas terbaik dengan harga yang kompetitif untuk setiap
                        proyek Anda.
                    </p>

                    <div class="space-y-4">
                        <div class="flex items-start gap-4">
                            <div
                                class="w-10 h-10 rounded-full bg-[#D4A574]/20 flex items-center justify-center flex-shrink-0">
                                <svg class="w-5 h-5 text-[#D4A574]" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                            <div>
                                <h4 class="font-semibold text-[#3E2723]">Kayu Berkualitas Tinggi</h4>
                                <p class="text-gray-600 text-sm">Setiap jenis kayu dipilih dengan teliti untuk kualitas
                                    terbaik</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div
                                class="w-10 h-10 rounded-full bg-[#D4A574]/20 flex items-center justify-center flex-shrink-0">
                                <svg class="w-5 h-5 text-[#D4A574]" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                            <div>
                                <h4 class="font-semibold text-[#3E2723]">Harga Bersaing</h4>
                                <p class="text-gray-600 text-sm">Harga langsung dari petani kayu tanpa perantara</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div
                                class="w-10 h-10 rounded-full bg-[#D4A574]/20 flex items-center justify-center flex-shrink-0">
                                <svg class="w-5 h-5 text-[#D4A574]" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                            <div>
                                <h4 class="font-semibold text-[#3E2723]">Pengiriman Seluruh Indonesia</h4>
                                <p class="text-gray-600 text-sm">Layanan pengiriman cepat dan aman ke seluruh nusantara
                                </p>
                            </div>
                        </div>
                    </div>

                    <a href="#kontak"
                        class="inline-flex items-center gap-2 text-[#D4A574] font-semibold mt-8 hover:gap-4 transition-all">
                        Hubungi Kami
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Products Section -->
    <section id="produk" class="py-20 md:py-32 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <div class="inline-flex items-center gap-2 bg-[#D4A574]/10 px-4 py-2 rounded-full mb-6">
                    <span class="w-2 h-2 bg-[#D4A574] rounded-full"></span>
                    <span class="text-[#D4A574] font-semibold text-sm">PRODUK KAMI</span>
                </div>
                <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-[#3E2723] mb-6">
                    Berbagai Jenis Kayu
                    <span class="gradient-text">Berkualitas</span>
                </h2>
                <p class="text-gray-600 text-lg max-w-2xl mx-auto">
                    Kami menyediakan berbagai jenis kayu untuk kebutuhan konstruksi, furnitur, dan proyek lainnya
                </p>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Product 1 -->
                <div class="scroll-animate product-card card-hover rounded-2xl overflow-hidden relative">
                    <div class="image-hover-zoom h-64">
                        <img src="https://images.unsplash.com/photo-1542601906990-b4d3fb7d5763?auto=format&fit=crop&w=600&q=80"
                            alt="Kayu Jati" class="w-full h-full object-cover">
                    </div>
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="text-xl font-bold text-[#3E2723]">Kayu Jati</h3>
                            <span
                                class="bg-[#D4A574]/20 text-[#D4A574] px-3 py-1 rounded-full text-sm font-medium">Best
                                Seller</span>
                        </div>
                        <p class="text-gray-600 text-sm mb-4">Kayu jati berkualitas premium dengan ketahanan terbaik,
                            cocok untuk furnitur dan konstruksi.</p>
                        <div class="flex items-center justify-between">
                            <span class="text-[#D4A574] font-bold">Mulai dari Rp 15.000.000/m³</span>
                            <button
                                class="w-10 h-10 rounded-full bg-[#3E2723] text-white flex items-center justify-center hover:bg-[#D4A574] transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Product 2 -->
                <div class="scroll-animate delay-100 product-card card-hover rounded-2xl overflow-hidden relative">
                    <div class="image-hover-zoom h-64">
                        <img src="https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&w=600&q=80"
                            alt="Kayu Merbau" class="w-full h-full object-cover">
                    </div>
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="text-xl font-bold text-[#3E2723]">Kayu Merbau</h3>
                            <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">Tahan
                                Rayap</span>
                        </div>
                        <p class="text-gray-600 text-sm mb-4">Kayu merbau dengan kekuatan ekstra dan ketahanan terhadap
                            rayap, ideal untuk outdoor.</p>
                        <div class="flex items-center justify-between">
                            <span class="text-[#D4A574] font-bold">Mulai dari Rp 12.000.000/m³</span>
                            <button
                                class="w-10 h-10 rounded-full bg-[#3E2723] text-white flex items-center justify-center hover:bg-[#D4A574] transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Product 3 -->
                <div class="scroll-animate delay-200 product-card card-hover rounded-2xl overflow-hidden relative">
                    <div class="image-hover-zoom h-64">
                        <img src="https://images.unsplash.com/photo-1583030230228-5278953049b0?auto=format&fit=crop&w=600&q=80"
                            alt="Kayu Sengon" class="w-full h-full object-cover">
                    </div>
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="text-xl font-bold text-[#3E2723]">Kayu Sengon</h3>
                            <span
                                class="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">Terjangkau</span>
                        </div>
                        <p class="text-gray-600 text-sm mb-4">Kayu sengon dengan harga ekonomis, cocok untuk kebutuhan
                            Triplek dan papan.</p>
                        <div class="flex items-center justify-between">
                            <span class="text-[#D4A574] font-bold">Mulai dari Rp 3.500.000/m³</span>
                            <button
                                class="w-10 h-10 rounded-full bg-[#3E2723] text-white flex items-center justify-center hover:bg-[#D4A574] transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Product 4 -->
                <div class="scroll-animate delay-300 product-card card-hover rounded-2xl overflow-hidden relative">
                    <div class="image-hover-zoom h-64">
                        <img src="https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?auto=format&fit=crop&w=600&q=80"
                            alt="Kayu Kelapa" class="w-full h-full object-cover">
                    </div>
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="text-xl font-bold text-[#3E2723]">Kayu Kelapa</h3>
                            <span
                                class="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-sm font-medium">Alamiah</span>
                        </div>
                        <p class="text-gray-600 text-sm mb-4">Kayu kelapa dengan tekstur unik dan alami, sempurna untuk
                            dekorasi dan kerajinan.</p>
                        <div class="flex items-center justify-between">
                            <span class="text-[#D4A574] font-bold">Mulai dari Rp 2.500.000/m³</span>
                            <button
                                class="w-10 h-10 rounded-full bg-[#3E2723] text-white flex items-center justify-center hover:bg-[#D4A574] transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 1. Animation Observer (Memunculkan elemen saat di-scroll)
            const observerOptions = {
                threshold: 0.1
            };

            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);

            const animatedElements = document.querySelectorAll('.scroll-animate, .scroll-animate-left, .scroll-animate-right');
            animatedElements.forEach(el => observer.observe(el));

            // 2. Mobile Menu Logic
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            const closeMobileMenu = document.getElementById('close-mobile-menu');

            if (mobileMenuBtn && mobileMenu && closeMobileMenu) {
                mobileMenuBtn.addEventListener('click', () => mobileMenu.classList.add('active'));
                closeMobileMenu.addEventListener('click', () => mobileMenu.classList.remove('active'));
            }

            // 3. Navbar Scroll Effect
            const navbar = document.getElementById('navbar');
            window.addEventListener('scroll', () => {
                if (window.scrollY > 50) {
                    navbar.classList.remove('nav-transparent');
                    navbar.classList.add('nav-solid');
                } else {
                    navbar.classList.add('nav-transparent');
                    navbar.classList.remove('nav-solid');
                }
            });

            // 4. Number Counter Animation
            const counters = document.querySelectorAll('.counter');
            counters.forEach(counter => {
                const target = +counter.getAttribute('data-target');
                const duration = 2000; 
                const increment = target / (duration / 16);
                
                let current = 0;
                const updateCounter = () => {
                    current += increment;
                    if (current < target) {
                        counter.innerText = Math.ceil(current);
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.innerText = target;
                    }
                };
                
                const counterObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            updateCounter();
                            counterObserver.unobserve(entry.target);
                        }
                    });
                });
                counterObserver.observe(counter);
            });
        });
    </script>
</body>
</html>

                <!-- Product 5 -->
                <div class="scroll-animate delay-400 product-card card-hover rounded-2xl overflow-hidden relative">
                    <div class="image-hover-zoom h-64">
                        <img src="https://images.unsplash.com/photo-1549216474-63302450d996?auto=format&fit=crop&w=600&q=80"
                            alt="Kayu Mahoni" class="w-full h-full object-cover">
                    </div>
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="text-xl font-bold text-[#3E2723]">Kayu Mahoni</h3>
                            <span
                                class="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium">Premium</span>
                        </div>
                        <p class="text-gray-600 text-sm mb-4">Kayu mahoni dengan warna merah kecokelatan yang indah,
                            favorit untuk furnitur kelas atas.</p>
                        <div class="flex items-center justify-between">
                            <span class="text-[#D4A574] font-bold">Mulai dari Rp 10.000.000/m³</span>
                            <button
                                class="w-10 h-10 rounded-full bg-[#3E2723] text-white flex items-center justify-center hover:bg-[#D4A574] transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Product 6 -->
                <div class="scroll-animate delay-500 product-card card-hover rounded-2xl overflow-hidden relative">
                    <div class="image-hover-zoom h-64">
                        <img src="https://images.unsplash.com/photo-1582582621959-48d27397dc69?auto=format&fit=crop&w=600&q=80"
                            alt="Kayu Borneo" class="w-full h-full object-cover">
                    </div>
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="text-xl font-bold text-[#3E2723]">Kayu Borneo</h3>
                            <span
                                class="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">Kuat</span>
                        </div>
                        <p class="text-gray-600 text-sm mb-4">Kayu borneo dengan kekuatan tinggi, cocok untuk
                            konstruksi berat dan balok bangunan.</p>
                        <div class="flex items-center justify-between">
                            <span class="text-[#D4A574] font-bold">Mulai dari Rp 8.000.000/m³</span>
                            <button
                                class="w-10 h-10 rounded-full bg-[#3E2723] text-white flex items-center justify-center hover:bg-[#D4A574] transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center mt-12">
                <a href="#kontak"
                    class="btn-wood px-8 py-3 rounded-full text-white font-semibold inline-flex items-center gap-2">
                    Lihat Semua Produk
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                </a>
            </div>
        </div>
    </section>

    <!-- Advantages Section -->
    <section id="keunggulan" class="py-20 md:py-32 bg-[#3E2723] relative overflow-hidden">
        <div class="absolute inset-0 opacity-10">
            <div class="absolute inset-0"
                style="background-image: url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23D4A574\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E');">
            </div>
            <div class="absolute inset-0 wood-grain-overlay"></div>
        </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center mb-16">
                <div class="inline-flex items-center gap-2 bg-[#D4A574]/20 px-4 py-2 rounded-full mb-6">
                    <span class="w-2 h-2 bg-[#D4A574] rounded-full"></span>
                    <span class="text-[#D4A574] font-semibold text-sm">KELEBIHAN KAMI</span>
                </div>
                <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
                    Mengapa Memilih
                    <span class="gradient-text">Kayu Jaya?</span>
                </h2>
                <p class="text-white/70 text-lg max-w-2xl mx-auto">
                    Kami memberikan layanan terbaik untuk memastikan kepuasan pelanggan dalam setiap transaksi
                </p>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div
                    class="scroll-animate bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 transition-all duration-300">
                    <div class="w-16 h-16 mx-auto mb-6 rounded-full bg-[#D4A574]/20 flex items-center justify-center">
                        <svg class="w-8 h-8 text-[#D4A574]" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Kualitas Terjamin</h3>
                    <p class="text-white/60 text-sm">Setiap kayu dipilih dengan teliti dan melalui proses quality
                        control yang ketat</p>
                </div>

                <div
                    class="scroll-animate delay-100 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 transition-all duration-300">
                    <div class="w-16 h-16 mx-auto mb-6 rounded-full bg-[#D4A574]/20 flex items-center justify-center">
                        <svg class="w-8 h-8 text-[#D4A574]" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Harga Pabrik</h3>
                    <p class="text-white/60 text-sm">Harga langsung dari sumber tanpa perantara, sehingga lebih
                        terjangkau</p>
                </div>

                <div
                    class="scroll-animate delay-200 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 transition-all duration-300">
                    <div class="w-16 h-16 mx-auto mb-6 rounded-full bg-[#D4A574]/20 flex items-center justify-center">
                        <svg class="w-8 h-8 text-[#D4A574]" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Pengiriman Cepat</h3>
                    <p class="text-white/60 text-sm">Layanan pengiriman cepat dan aman ke seluruh Indonesia dengan
                        armada sendiri</p>
                </div>

                <div
                    class="scroll-animate delay-300 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 transition-all duration-300">
                    <div class="w-16 h-16 mx-auto mb-6 rounded-full bg-[#D4A574]/20 flex items-center justify-center">
                        <svg class="w-8 h-8 text-[#D4A574]" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Tim Profesional</h3>
                    <p class="text-white/60 text-sm">Tim yang berpengalaman dan siap membantu Anda 24/7</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section id="galeri" class="py-20 md:py-32 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <div class="inline-flex items-center gap-2 bg-[#D4A574]/10 px-4 py-2 rounded-full mb-6">
                    <span class="w-2 h-2 bg-[#D4A574] rounded-full"></span>
                    <span class="text-[#D4A574] font-semibold text-sm">GALERI PROYEK</span>
                </div>
                <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-[#3E2723] mb-6">
                    Dokumentasi
                    <span class="gradient-text">Pekerjaan Kami</span>
                </h2>
                <p class="text-gray-600 text-lg max-w-2xl mx-auto">
                    Lihat bagaimana kami memproses kayu berkualitas hingga sampai ke tangan pelanggan
                </p>
            </div>

            <!-- Video Container -->
            <div class="scroll-animate rounded-2xl overflow-hidden shadow-2xl mb-12 relative group">
                <div
                    class="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-all duration-500 z-10 pointer-events-none">
                </div>
                <video class="w-full h-[400px] md:h-[600px] object-cover" controls
                    poster="https://images.unsplash.com/photo-1504198458649-3128b932f49e?auto=format&fit=crop&w=1200&q=80">
                    <source src="https://videos.pexels.com/video-files/3995236/3995236-hd_1920_1080_25fps.mp4"
                        type="video/mp4">
                    Browser Anda tidak mendukung tag video.
                </video>
            </div>

            <!-- Image Grid -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div
                    class="scroll-animate delay-100 relative group overflow-hidden rounded-xl h-64 md:h-80 md:col-span-2">
                    <img src="https://images.unsplash.com/photo-1617103996702-96ff29b1c467?auto=format&fit=crop&w=800&q=80"
                        alt="Gudang Kayu"
                        class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                    <div
                        class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                        <p class="text-white font-semibold">Gudang Penyimpanan</p>
                    </div>
                </div>
                <div class="scroll-animate delay-200 relative group overflow-hidden rounded-xl h-64 md:h-80">
                    <img src="https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&w=600&q=80"
                        alt="Proses Pemotongan"
                        class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                    <div
                        class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                        <p class="text-white font-semibold">Pemotongan</p>
                    </div>
                </div>
                <div class="scroll-animate delay-300 relative group overflow-hidden rounded-xl h-64 md:h-80">
                    <img src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80"
                        alt="Pengiriman"
                        class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                    <div
                        class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                        <p class="text-white font-semibold">Pengiriman</p>
                    </div>
                </div>
                <div class="scroll-animate delay-400 relative group overflow-hidden rounded-xl h-64 md:h-80">
                    <img src="https://images.unsplash.com/photo-1582582621959-48d27397dc69?auto=format&fit=crop&w=600&q=80"
                        alt="Detail Kayu"
                        class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                    <div
                        class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                        <p class="text-white font-semibold">Detail Serat</p>
                    </div>
                </div>
                <div
                    class="scroll-animate delay-500 relative group overflow-hidden rounded-xl h-64 md:h-80 md:col-span-3">
                    <img src="https://images.unsplash.com/photo-1505577058444-a3dab90d4253?auto=format&fit=crop&w=1200&q=80"
                        alt="Proyek Konstruksi"
                        class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                    <div
                        class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                        <p class="text-white font-semibold">Proyek Konstruksi</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="testimoni" class="py-20 md:py-32 bg-[#F5F0EB]">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <div class="inline-flex items-center gap-2 bg-[#D4A574]/10 px-4 py-2 rounded-full mb-6">
                    <span class="w-2 h-2 bg-[#D4A574] rounded-full"></span>
                    <span class="text-[#D4A574] font-semibold text-sm">TESTIMONI</span>
                </div>
                <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-[#3E2723] mb-6">
                    Apa Kata
                    <span class="gradient-text">Pelanggan Kami?</span>
                </h2>
                <p class="text-gray-600 text-lg max-w-2xl mx-auto">Kepuasan pelanggan adalah prioritas utama kami</p>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="scroll-animate testimonial-card rounded-2xl p-8">
                    <div class="flex items-center gap-1 mb-4">
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                    </div>
                    <p class="text-gray-600 mb-6 italic">"Sangat puas dengan kualitas kayu dari Kayu Jaya. Warna dan
                        teksturnya sesuai dengan yang saya harapkan. Pokoknya recomended!"</p>
                    <div class="flex items-center gap-4">
                        <div
                            class="w-12 h-12 rounded-full bg-[#3E2723] flex items-center justify-center text-white font-bold">
                            AS</div>
                        <div>
                            <h4 class="font-semibold text-[#3E2723]">Andreas Susanto</h4>
                            <p class="text-gray-500 text-sm">Pengusaha Furnitur</p>
                        </div>
                    </div>
                </div>

                <div class="scroll-animate delay-100 testimonial-card rounded-2xl p-8">
                    <div class="flex items-center gap-1 mb-4">
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                    </div>
                    <p class="text-gray-600 mb-6 italic">"Harga sangat bersaing dan pengiriman cepat. Sudah langganan
                        di sini selama 5 tahun dan tidak pernah kecewa."</p>
                    <div class="flex items-center gap-4">
                        <div
                            class="w-12 h-12 rounded-full bg-[#D4A574] flex items-center justify-center text-white font-bold">
                            BP</div>
                        <div>
                            <h4 class="font-semibold text-[#3E2723]">Budi Prasetyo</h4>
                            <p class="text-gray-500 text-sm">Kontraktor Bangunan</p>
                        </div>
                    </div>
                </div>

                <div class="scroll-animate delay-200 testimonial-card rounded-2xl p-8">
                    <div class="flex items-center gap-1 mb-4">
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg class="w-5 h-5 text-[#D4A574]" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
